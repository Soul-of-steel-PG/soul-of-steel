﻿using System;
using UnityEngine;

public class Nickname : MonoBehaviour
{
}