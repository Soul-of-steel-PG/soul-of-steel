﻿using UnityEngine;

public class WaitingForOpponentPanel : MonoBehaviour {
}